import React from 'react';

function Header(props) {
    return (
        <div className={props.className}>
            <h1>Simple gallery</h1>
        </div>
    )
}
export default Header